///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>

///Dado un conjunto de n�meros que termina con un valor 0, calcular e informar cu�ntos de esos
///n�meros son n�meros primos.
///El valor 0 no forma parte de la lista a analizar. Se usa para finalizar

using namespace std;



///Funci�n: es un fragmento de c�digo que resuelve un problema en particular.
///Las funciones tienen un nombre, pueden recibir par�metros, y pueden devolver UN valor


///La funci�n esPrimo() devuelve un 1 si el n�mero que recibe es primo, y un 0 si no lo es



bool esPrimo(int n);///Declaraci�n, prototipo o firma de la funci�n

int main(){
    int num, cantPrimos=0;
    bool valorDevuelto;
    cout<<"INGRESAR UN NUMERO ";
    cin>>num;

    while(num!=0){
        valorDevuelto=esPrimo(num);
        if(valorDevuelto==true){
            cantPrimos++;
        }
        cout<<"INGRESAR UN NUMERO ";
        cin>>num;
    }
	cout<<"CANTIDAD DE PRIMOS "<<cantPrimos<<endl;
	system("pause");
	return 0;
}




bool esPrimo(int n){
    int i, cantDivisores=0;
    for(i=1;i<=n;i++){
            if(n%i==0){
                cantDivisores++;
        }
    }
    if(cantDivisores==2){
        return true;
    }
    return false;
}








