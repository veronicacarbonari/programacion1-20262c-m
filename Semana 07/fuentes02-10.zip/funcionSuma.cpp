///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>


using namespace std;

///hacer una funci�n de nombre suma, que reciba 2 n�meros enteros, y devuelva la suma de
///los n�meros recibidos

int suma(int n1, int n2);///declaraci�n

int main(){
    int num1, num2;
    cout<<"INGRESAR UN NUMERO ";
    cin>>num1;
    cout<<"INGRESAR UN NUMERO ";
    cin>>num2;
    int resultado=suma(num1,num2);
    cout<<"LA SUMA ES (muestro la variable resultado)"<<resultado<<endl<<endl;
    cout<<"LA SUMA ES (muestro lo que devuelve la funcion) "<<suma(num1, num2)<<endl;

    resultado=suma(10,20);
    cout<<"LA SUMA ES (muestro la variable resultado, pero la funcion recibe numeros )"<<resultado<<endl<<endl;

    resultado=suma(suma(10,20),suma(5,5));

    cout<<"LA SUMA ES (muestro la variable resultado, pero la funcion recibe numeros )"<<resultado<<endl<<endl;
	system("pause");
	return 0;
}


int suma(int n1, int n2){///desarrollo
    int suma;
    suma=n1+n2;
    return suma;
}
