///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>


using namespace std;

///int, float,char, bool, void
void cartelBienvenida();///prototipo
void cartelDespedida();

void cartelUnico(int queHago);
void cartelUnicoInternacional(int queHago);
///1: Bienvenida en castellano; 2: Despedida en castellano
///3: Bienvenida en alem�n; 4: Despedida en alem�n

int main(){
    int tipoSaludo;
    cout<<"INGRESAR QUE SALUDO SE QUIERE ";
    cin>>tipoSaludo;
    cartelUnicoInternacional(tipoSaludo);
    cout<<"INGRESAR QUE SALUDO SE QUIERE ";
    cin>>tipoSaludo;
    cartelUnicoInternacional(tipoSaludo);
	system("pause");
	return 0;
}

void cartelBienvenida(){///desarrollo. Funci�n completa
    cout<<"HOLA!!!!"<<endl;
}
void cartelDespedida(){
    cout<<"CHAUUUUU!!!!!"<<endl;
}


void cartelUnico(int queHago){
    if(queHago==23){
        cout<<"HOLA!!!!"<<endl;
    }
    else{
        cout<<"CHAUUUUU!!!!!"<<endl;
    }
}

void cartelUnicoInternacional(int queHago){
    switch(queHago){
        case 1: cout<<"HOLA!!!!!";
                break;
        case 2: cout<<"CHAU!!!!!";
                break;
        case 3: cout<<"HALLO!!!!!";
                break;
        case 4: cout<<"TCHUSS!!!!!";
                break;
        default: cout<<"TE EQUIVOCASTE CON EL PARAMETRO!!!!!"<<endl;
                break;
    }
    cout<<endl;
}
